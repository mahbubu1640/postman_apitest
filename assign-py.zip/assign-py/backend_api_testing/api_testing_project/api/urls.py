from django.urls import path
from api.views import UserLoginView, UserRegisterView, UserProfileUpdateView, UserLogoutView

urlpatterns = [
    path('auth/login/', UserLoginView.as_view(), name='user-login'),
    path('auth/register/', UserRegisterView.as_view(), name='user-register'),
    path('profile/update/', UserProfileUpdateView.as_view(), name='profile-update'),
    path('auth/logout/', UserLogoutView.as_view(), name='user-logout'),
]
